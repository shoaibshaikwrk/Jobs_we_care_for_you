// Field mappings for the three ATS platforms this extension is optimized
// for. Each function fills what it can and returns { filled: <count> }.
// These run inside whichever frame actually matched the platform's hostname
// (see detect-and-fill.js) — which is what makes this work even when a
// company embeds the form in an iframe on their own branded careers domain
// (e.g. careers.company.com embedding boards.greenhouse.io in an <iframe>):
// the content script attaches per-frame, by that frame's own URL, not the
// top-level page's URL.

function jaFillGreenhouse(profile) {
  let filled = 0;
  const count = (ok) => { if (ok) filled++; };

  // ID-based selectors match Greenhouse's classic embed template; label-text
  // fallback catches their newer job-board template, which doesn't always
  // use these ids. "exact" mode avoids "First Name" matching into a
  // separate "Preferred First Name" field some companies add.
  count(jaFillField("#first_name", profile.firstName) || jaFillByLabelText(["first name"], profile.firstName, document, "exact"));
  count(jaFillField("#last_name", profile.lastName) || jaFillByLabelText(["last name"], profile.lastName, document, "exact"));
  count(jaFillField("#email", profile.email) || jaFillByLabelText(["email"], profile.email, document, "exact"));
  count(jaFillField("#phone", profile.phone) || jaFillByLabelText(["phone"], profile.phone, document, "exact"));

  // Location is sometimes a plain text input, sometimes a Google-Places
  // autocomplete widget — only plain text inputs can be set this way.
  count(jaFillField('input[id*="location" i]', profile.location) || jaFillByLabelText(["location", "city"], profile.location));

  count(jaSetFileInput('#resume, input[type="file"][name*="resume" i]', profile.resume) || jaSetFileInputByContext(profile.resume, ["resume", "cv"]));
  if (profile.coverLetterText) {
    count(jaFillField('#cover_letter_text, textarea[name*="cover_letter" i]', profile.coverLetterText));
  }

  count(jaFillByLabelText(["linkedin"], profile.linkedinUrl));
  count(jaFillByLabelText(["portfolio", "website", "personal site"], profile.portfolioUrl));
  count(jaFillByLabelText(["github"], profile.githubUrl));
  count(jaFillByLabelText(["current company", "current employer"], profile.currentCompany));

  return { filled };
}

function jaFillLever(profile) {
  let filled = 0;
  const count = (ok) => { if (ok) filled++; };

  count(jaFillField('input[name="name"]', profile.fullName) || jaFillByLabelText(["full name", "name"], profile.fullName, document, "exact"));
  count(jaFillField('input[name="email"]', profile.email) || jaFillByLabelText(["email"], profile.email, document, "exact"));
  count(jaFillField('input[name="phone"]', profile.phone) || jaFillByLabelText(["phone"], profile.phone, document, "exact"));
  count(jaFillField('input[name="org"]', profile.currentCompany)); // "Current company" on Lever
  count(jaFillField('input[name="urls[LinkedIn]"]', profile.linkedinUrl));
  count(jaFillField('input[name="urls[GitHub]"]', profile.githubUrl));
  count(jaFillField('input[name="urls[Portfolio]"]', profile.portfolioUrl));
  count(jaFillField('input[name="urls[Twitter]"]', profile.twitterUrl));

  count(jaSetFileInput('input[name="resume"]', profile.resume) || jaSetFileInputByContext(profile.resume, ["resume", "cv"]));

  if (profile.coverLetterText) {
    count(jaFillField('textarea[name="comments"]', profile.coverLetterText));
  }

  count(jaFillByLabelText(["linkedin"], profile.linkedinUrl));
  count(jaFillByLabelText(["portfolio", "website"], profile.portfolioUrl));
  count(jaFillByLabelText(["github"], profile.githubUrl));

  return { filled };
}

function jaFillAshby(profile) {
  let filled = 0;
  const count = (ok) => { if (ok) filled++; };

  count(jaFillField('input[name="_systemfield_name"]', profile.fullName) || jaFillByLabelText(["full name", "name"], profile.fullName, document, "exact"));
  count(jaFillField('input[name="_systemfield_email"]', profile.email) || jaFillByLabelText(["email"], profile.email, document, "exact"));
  count(jaFillField('input[name="_systemfield_phone"]', profile.phone) || jaFillByLabelText(["phone"], profile.phone, document, "exact"));
  count(jaFillField('input[name="_systemfield_location"]', profile.location) || jaFillByLabelText(["location"], profile.location));

  count(jaSetFileInputByContext(profile.resume, ["resume", "cv"]));

  count(jaFillByLabelText(["linkedin"], profile.linkedinUrl));
  count(jaFillByLabelText(["portfolio", "website", "personal site"], profile.portfolioUrl));
  count(jaFillByLabelText(["github"], profile.githubUrl));
  count(jaFillByLabelText(["current company", "current employer"], profile.currentCompany));

  return { filled };
}
