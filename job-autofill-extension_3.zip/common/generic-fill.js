// Best-effort autofill for any site that isn't recognized as Greenhouse,
// Lever, or Ashby. Runs automatically wherever detect-and-fill.js decides
// the current frame looks like a job application (see that file) — so,
// unlike the old version, this is no longer limited to only firing when the
// user manually clicks from the popup on an unsupported page.
//
// Strategy, in priority order:
//   1. The HTML `autocomplete` attribute — the most reliable signal, since
//      it's the same hint browsers themselves use for native autofill.
//   2. Label/placeholder/name/id text heuristics (every input is checked
//      directly, not only ones with an associated <label>, since many
//      custom form frameworks skip <label for="">).
//   3. Any file input, matched by nearby text mentioning "resume"/"cv".
//
// Reliability here is necessarily lower than the platform-specific fillers —
// every custom-built application form has a different DOM — so this reports
// what it found and leaves the rest for the user.

const JA_AUTOCOMPLETE_MAP = {
  "given-name": "firstName",
  "family-name": "lastName",
  name: "fullName",
  email: "email",
  tel: "phone",
  "tel-national": "phone",
  organization: "currentCompany",
  "address-level2": "location",
  url: "portfolioUrl",
};

const JA_LABEL_PATTERNS = [
  { patterns: ["first name", "given name"], field: "firstName", mode: "exact" },
  { patterns: ["last name", "surname", "family name"], field: "lastName", mode: "exact" },
  { patterns: ["full name", "your name", "name"], field: "fullName", mode: "exact" },
  { patterns: ["email"], field: "email", mode: "exact" },
  { patterns: ["phone", "mobile"], field: "phone", mode: "contains" },
  { patterns: ["location", "city"], field: "location", mode: "contains" },
  { patterns: ["current company", "current employer", "employer"], field: "currentCompany", mode: "contains" },
  { patterns: ["linkedin"], field: "linkedinUrl", mode: "contains" },
  { patterns: ["portfolio", "website", "personal site"], field: "portfolioUrl", mode: "contains" },
  { patterns: ["github"], field: "githubUrl", mode: "contains" },
];

function jaFillGeneric(profile) {
  let filled = 0;
  const seen = new Set();

  // Pass 1: autocomplete attribute (most reliable).
  document.querySelectorAll("input, textarea").forEach((el) => {
    const token = (el.getAttribute("autocomplete") || "").toLowerCase();
    const field = JA_AUTOCOMPLETE_MAP[token];
    if (!field || !profile[field]) return;
    if (el.value && el.value.trim().length > 0) return;
    jaSetNativeValue(el, profile[field]);
    seen.add(el);
  });

  // Pass 2: label/placeholder/name/id text heuristics, for anything pass 1 missed.
  document.querySelectorAll("input, textarea").forEach((el) => {
    if (seen.has(el)) return;
    if (el.type === "hidden" || el.type === "file" || el.type === "checkbox" || el.type === "radio") return;
    if (el.value && el.value.trim().length > 0) return;

    const label = el.closest("label")?.textContent ||
      (el.id && document.querySelector(`label[for="${CSS.escape(el.id)}"]`)?.textContent) ||
      "";
    const normalizedLabel = jaNormalizeLabel(label);
    const context = [el.placeholder, el.name, el.id, el.getAttribute("aria-label")]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();

    for (const { patterns, field, mode } of JA_LABEL_PATTERNS) {
      if (!profile[field]) continue;
      const labelHit = mode === "exact" ? patterns.includes(normalizedLabel) : patterns.some((p) => normalizedLabel.includes(p));
      const contextHit = patterns.some((p) => context.includes(p));
      if (labelHit || contextHit) {
        jaSetNativeValue(el, profile[field]);
        seen.add(el);
        break;
      }
    }
  });

  filled = seen.size;

  // Resume file, best effort.
  if (jaSetFileInputByContext(profile.resume, ["resume", "cv"])) filled++;

  return { filled };
}
