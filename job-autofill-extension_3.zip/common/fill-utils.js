// Shared helpers used by every fill script. Loaded first (see manifest.json
// content_scripts) so platform-fillers.js, generic-fill.js, and
// detect-and-fill.js can all call these.

/**
 * Sets a value on a text/textarea input in a way that React, Vue, and other
 * frameworks with "controlled" inputs actually notice (plain `el.value = x`
 * gets silently overwritten by the framework's own state on the next render).
 * This uses the native property setter directly, bypassing any overridden
 * setter the framework installed on the element instance.
 */
function jaSetNativeValue(element, value) {
  const proto = Object.getPrototypeOf(element);
  const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
  const nativeSetter = descriptor && descriptor.set;
  if (nativeSetter) {
    nativeSetter.call(element, value);
  } else {
    element.value = value;
  }
  element.dispatchEvent(new Event("input", { bubbles: true }));
  element.dispatchEvent(new Event("change", { bubbles: true }));
}

/** Fills a plain <input>/<textarea> if it exists and is currently empty. */
function jaFillField(selector, value, root = document) {
  if (!value) return false;
  const el = root.querySelector(selector);
  if (!el) return false;
  if (el.value && el.value.trim().length > 0) return false; // don't clobber something already typed
  jaSetNativeValue(el, value);
  return true;
}

/** Selects a matching <option> in a <select> by visible text (case-insensitive, partial match). */
function jaSelectByText(selector, text, root = document) {
  if (!text) return false;
  const el = root.querySelector(selector);
  if (!el || el.tagName !== "SELECT") return false;
  const target = text.trim().toLowerCase();
  const match = Array.from(el.options).find(
    (o) => o.textContent.trim().toLowerCase().includes(target)
  );
  if (!match) return false;
  el.value = match.value;
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function jaNormalizeLabel(text) {
  return (text || "").replace(/[*✱:]/g, "").trim().toLowerCase();
}

/**
 * Custom questions (and, on non-standard form builds, even the basic name/
 * email/phone fields) don't have stable element IDs across different
 * companies' ATS instances, but they almost always have a visible <label>
 * with recognizable wording. This scans all labels on the page, matches
 * against a list of substrings, and fills the associated input/textarea/
 * select if it's currently empty.
 *
 * mode "exact" requires the label's normalized text to exactly equal one of
 * the patterns (use this for fields like "First Name" that would otherwise
 * false-match a field like "Preferred First Name"). mode "contains" (the
 * default) does a substring match, better for looser one-off patterns like
 * "linkedin" or "portfolio".
 */
function jaFillByLabelText(labelPatterns, value, root = document, mode = "contains") {
  if (!value) return false;
  const patterns = labelPatterns.map((p) => p.toLowerCase());
  const labels = Array.from(root.querySelectorAll("label"));
  for (const label of labels) {
    const normalized = jaNormalizeLabel(label.textContent);
    const isMatch =
      mode === "exact" ? patterns.includes(normalized) : patterns.some((p) => normalized.includes(p));
    if (!isMatch) continue;

    let input = null;
    const forId = label.getAttribute("for");
    if (forId) {
      input = (root.getElementById ? root.getElementById(forId) : document.getElementById(forId));
    }
    if (!input) {
      input = label.querySelector("input, textarea, select") ||
        (label.parentElement && label.parentElement.querySelector("input, textarea, select"));
    }
    if (!input) continue;
    if (input.value && input.value.trim().length > 0) continue; // don't clobber

    if (input.tagName === "SELECT") {
      jaSelectByText(`#${CSS.escape(input.id)}`, value, root);
    } else {
      jaSetNativeValue(input, value);
    }
    return true;
  }
  return false;
}

/**
 * Attaches a stored resume (base64) to a file input as if the user picked it
 * from disk. This is the standard DataTransfer technique for programmatically
 * setting <input type="file">.files — it only works within a page/frame the
 * extension has permission for, and only with a file the user uploaded into
 * the extension themselves (see popup.js).
 */
function jaSetFileInput(selector, fileData, root = document) {
  if (!fileData || !fileData.base64) return false;
  const input = root.querySelector(selector);
  if (!input || input.type !== "file") return false;
  try {
    const byteChars = atob(fileData.base64);
    const byteNumbers = new Array(byteChars.length);
    for (let i = 0; i < byteChars.length; i++) byteNumbers[i] = byteChars.charCodeAt(i);
    const byteArray = new Uint8Array(byteNumbers);
    const file = new File([byteArray], fileData.fileName, { type: fileData.mimeType });
    const dt = new DataTransfer();
    dt.items.add(file);
    input.files = dt.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.dispatchEvent(new Event("input", { bubbles: true }));
    return true;
  } catch (err) {
    console.warn("[Job Autofill] Could not attach resume:", err);
    return false;
  }
}

function jaCssPathFor(el) {
  if (el.id) return `#${CSS.escape(el.id)}`;
  if (el.name) return `input[name="${CSS.escape(el.name)}"]`;
  const all = Array.from(document.querySelectorAll('input[type="file"]'));
  const idx = all.indexOf(el);
  return `input[type="file"]:nth-of-type(${idx + 1})`;
}

/**
 * For pages where the resume file input isn't at a predictable selector,
 * find a file input whose surrounding text mentions one of the given
 * keywords, falling back to the only file input on the page if there's just
 * one, or the first one otherwise.
 */
function jaSetFileInputByContext(fileData, keywords, root = document) {
  if (!fileData || !fileData.base64) return false;
  const fileInputs = Array.from(root.querySelectorAll('input[type="file"]'));
  if (fileInputs.length === 0) return false;
  if (fileInputs.length === 1) {
    return jaSetFileInput(jaCssPathFor(fileInputs[0]), fileData, root);
  }
  const target = keywords.map((k) => k.toLowerCase());
  for (const input of fileInputs) {
    const context = (
      (input.closest("label, fieldset, div")?.textContent || "") + " " + (input.name || "") + " " + (input.id || "")
    ).toLowerCase();
    if (target.some((k) => context.includes(k))) {
      return jaSetFileInput(jaCssPathFor(input), fileData, root);
    }
  }
  return jaSetFileInput(jaCssPathFor(fileInputs[0]), fileData, root);
}

/** Small on-page toast so the user gets feedback without opening the popup. */
function jaShowToast(message) {
  const existing = document.getElementById("ja-autofill-toast");
  if (existing) existing.remove();
  const toast = document.createElement("div");
  toast.id = "ja-autofill-toast";
  toast.textContent = message;
  Object.assign(toast.style, {
    position: "fixed",
    bottom: "20px",
    right: "20px",
    zIndex: 2147483647,
    background: "#1f2937",
    color: "#fff",
    padding: "12px 16px",
    borderRadius: "8px",
    fontFamily: "system-ui, -apple-system, sans-serif",
    fontSize: "13px",
    maxWidth: "320px",
    boxShadow: "0 4px 16px rgba(0,0,0,0.25)",
    lineHeight: "1.4",
  });
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 7000);
}

/** Injects a floating "Fill my info" button on the page (idempotent). */
function jaInjectFillButton(onClick) {
  if (document.getElementById("ja-autofill-btn")) return;
  if (!document.body) return;
  const btn = document.createElement("button");
  btn.id = "ja-autofill-btn";
  btn.textContent = "⚡ Fill my info";
  Object.assign(btn.style, {
    position: "fixed",
    bottom: "20px",
    right: "20px",
    zIndex: 2147483646,
    background: "#2563eb",
    color: "#fff",
    border: "none",
    borderRadius: "999px",
    padding: "10px 18px",
    fontFamily: "system-ui, -apple-system, sans-serif",
    fontSize: "14px",
    fontWeight: "600",
    cursor: "pointer",
    boxShadow: "0 4px 12px rgba(37,99,235,0.4)",
  });
  btn.addEventListener("click", onClick);
  document.body.appendChild(btn);
}

/** Reads the saved profile from extension storage. Returns a Promise. */
function jaGetProfile() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["jaProfile"], (result) => {
      resolve(result.jaProfile || null);
    });
  });
}
