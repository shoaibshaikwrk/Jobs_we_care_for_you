// Runs in every frame of every page (see manifest.json: matches <all_urls>,
// all_frames: true) — including iframes, which is what makes this work when
// a company embeds their Greenhouse/Lever/Ashby form inside their own
// branded careers domain instead of linking straight to it. The content
// script attaches per-frame by that frame's own URL, so the iframe carrying
// the real form gets it even though the parent page's domain is unknown to
// this extension.
//
// It does two things, and only two: (1) decide, from the page's own DOM,
// whether this looks like a job application form, and if so show the
// floating fill button; (2) fill known fields when asked, via that button
// or via a message from the popup. It never scans page content for
// anything other than that local decision, and nothing it finds is sent
// anywhere — see the privacy policy for the full data-handling picture.

const JA_KNOWN_HOSTS = {
  "boards.greenhouse.io": jaFillGreenhouse,
  "job-boards.greenhouse.io": jaFillGreenhouse,
  "jobs.lever.co": jaFillLever,
  "jobs.ashbyhq.com": jaFillAshby,
};

/**
 * Cheap, local heuristic for "is this a job application form" — no network
 * calls, no data collection, just counting signals already visible in the
 * DOM. Deliberately conservative: a stray file input or a lone email field
 * (e.g. a newsletter signup) shouldn't be enough on its own to show the
 * button on every page you visit.
 */
function jaLooksLikeApplicationForm() {
  if (!document.body) return false;

  let score = 0;

  const fileInputs = document.querySelectorAll('input[type="file"]');
  if (fileInputs.length > 0) score += 2;

  const hasFieldMatchingAutocomplete = (tokens) =>
    Array.from(document.querySelectorAll("input")).some((el) =>
      tokens.includes((el.getAttribute("autocomplete") || "").toLowerCase())
    );
  if (hasFieldMatchingAutocomplete(["given-name", "family-name", "name"])) score += 1;
  if (hasFieldMatchingAutocomplete(["email"])) score += 1;
  if (hasFieldMatchingAutocomplete(["tel", "tel-national"])) score += 1;

  // Fall back to label text for sites that skip autocomplete attributes.
  const labelText = Array.from(document.querySelectorAll("label"))
    .map((l) => jaNormalizeLabel(l.textContent))
    .join(" | ");
  if (/\bresume\b|\bcv\b/.test(labelText)) score += 1;
  if (/first name|last name|full name/.test(labelText)) score += 1;
  if (/email/.test(labelText)) score += 1;

  const haystack = (document.title + " " + location.href).toLowerCase();
  if (/apply|application|job-boards|greenhouse|lever\.co|ashbyhq/.test(haystack)) score += 1;

  return score >= 3;
}

async function jaRunFillNow() {
  const profile = await jaGetProfile();
  if (!profile) {
    jaShowToast("No saved profile yet. Open the extension popup and fill in your info first.");
    return { filled: 0, message: "no-profile" };
  }

  const knownFiller = JA_KNOWN_HOSTS[location.hostname];
  const result = knownFiller ? knownFiller(profile) : jaFillGeneric(profile);
  const isKnown = Boolean(knownFiller);

  jaShowToast(
    result.filled > 0
      ? isKnown
        ? `Filled ${result.filled} field(s). Review everything (including any custom questions) before you submit.`
        : `Best-effort fill: ${result.filled} field(s) on this non-standard form. Double-check carefully before submitting.`
      : "Couldn't confidently match any fields on this page/form — fill it in manually."
  );
  return result;
}

// Let the popup trigger a fill on demand, from any frame.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "JA_FILL_NOW") {
    jaRunFillNow().then((result) => sendResponse(result));
    return true; // keep the message channel open for the async response
  }
});

// Auto-detect on load, and a couple of times shortly after — some
// application forms (Ashby in particular) render in after the initial
// page load, so a single check on document_idle can miss them.
function jaMaybeShowButton() {
  if (JA_KNOWN_HOSTS[location.hostname] || jaLooksLikeApplicationForm()) {
    jaInjectFillButton(jaRunFillNow);
  }
}

jaMaybeShowButton();
setTimeout(jaMaybeShowButton, 1500);
setTimeout(jaMaybeShowButton, 3500);
