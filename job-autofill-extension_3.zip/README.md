# Job Application Autofill

A Chrome extension that detects job application forms **on any site** and
fills your saved profile (name, contact info, LinkedIn/portfolio/GitHub
links, resume file) into them. It has optimized field mapping for
**Greenhouse**, **Lever**, and **Ashby** — the platforms your
`jobs.placeonus.com` job checker already tracks companies on — which also
works when a company embeds one of those forms inside their own branded
careers page (e.g. `careers.company.com` showing a Greenhouse form in an
iframe). Everywhere else, it falls back to best-effort matching by each
field's `autocomplete` attribute and label text. It also has an optional AI
resume-vs-job-description keyword check.

**It never clicks Submit for you.** Every field it fills is something you can
see and edit before you send the application yourself, on the company's own
site, in your own browser session. That's a deliberate choice, not a
limitation — LinkedIn/Indeed-style full auto-submission runs into Terms of
Service restrictions and bot-detection on most platforms, the exact reason
the job checker itself only reads public APIs instead of scraping.

## What it does

- **Auto-detects job application forms as you browse.** A lightweight,
  local check (file upload field present + name/email/phone-style fields +
  wording like "resume" or "apply") decides whether the current page looks
  like an application. If so, a **"⚡ Fill my info"** button appears
  bottom-right — no need to already know the site is Greenhouse/Lever/Ashby.
  This check runs entirely in your browser and sends nothing anywhere; see
  the [privacy policy](https://claude.ai/code/artifact/5112c888-7c09-454f-9655-72f2183b4fa2)
  for the full picture.
- **Also runs inside iframes.** If a company embeds their Greenhouse/Lever/
  Ashby form inside their own careers domain, the extension still recognizes
  and fills it — detection happens per-frame, by that frame's own URL, not
  just the page you see in the address bar.
- Also fillable anytime from the extension's popup ("Fill this page"
  button), which works even on a tab that was already open before you
  installed the extension.
- Fills: first/last name, email, phone, location, current company, LinkedIn
  URL, portfolio/website URL, GitHub URL, your resume file, and an optional
  cover-letter text block — whichever of those fields the specific form
  actually has.
- Leaves company-specific custom questions (EEO/demographic questions, work
  authorization, "why do you want to work here," etc.) untouched — those
  vary too much to fill reliably and are exactly the parts you should be
  answering yourself anyway.
- Never overwrites a field you've already typed something into.
- **"Analyze match"** (in the popup): paste a job description, and with your
  own OpenAI API key saved, it flags keywords from the posting that your
  resume text might be missing — called directly from your browser to
  OpenAI, no relay server involved.

## A note on the permission this needs

To auto-detect forms on **any** site (not just three known domains) and to
work inside embedded iframes, this extension asks for access to all sites
(`<all_urls>` in the manifest) instead of a short list of specific domains.
Chrome will show a stronger install warning for this
("Read and change all your data on all the websites you visit") — that's
expected, not a bug. In exchange: the detection logic itself is entirely
local (DOM inspection only, no network calls, nothing logged or sent
anywhere), and it only ever *acts* — showing the button, filling fields —
when its heuristic actually recognizes an application form. It's the same
trade every password manager and form-filler extension makes for the same
reason.

## Install it (not published to the Chrome Web Store — "load unpacked")

A visual, step-by-step version of this same walkthrough (with a
troubleshooting section) is here:
**https://claude.ai/code/artifact/0ed32cc6-4deb-4a0c-a3a1-90f1eafa4a93**

Works the same way in Chrome, Edge (`edge://extensions`), and Brave
(`brave://extensions`), since all three are Chromium-based — just swap the
address in step 2 for whichever browser you use.

1. **Unzip the file.** Find `job-autofill-extension.zip` (usually in
   Downloads) and double-click it — on a Mac this creates a folder of the
   same name right next to it; on Windows, right-click → **Extract All**.
   Keep the resulting folder somewhere permanent — the browser reads the
   extension from these files every time it starts, not just at install
   time, so deleting or moving the folder later will disable it.
2. **Open the Extensions page.** In your browser's address bar, type
   `chrome://extensions` and press Enter.
3. **Turn on Developer mode.** Top-right corner of that page — click the
   toggle so it turns on. Three new buttons appear.
4. **Click "Load unpacked."** A file picker opens. Navigate to the
   unzipped folder from step 1 and select the folder itself (not the
   `.zip` file, and not a subfolder inside it like `content-scripts`) —
   the folder you want directly contains `manifest.json`. Click
   Select/Open.
5. **Confirm it worked.** A card titled "Job Application Autofill" with
   the blue lightning-bolt icon appears on the Extensions page. Click the
   puzzle-piece icon in your toolbar (top-right, next to the address bar)
   and click the pin next to it so the icon stays visible.

**Updating from an older version:** unzip the new version over the old
folder, go to `chrome://extensions`, find the extension's card, and click
its reload icon. Then **reload any application tabs you already had open**
— Chrome only applies a content-script change to tabs opened after the
reload. Your saved profile and resume aren't touched either way — they're
stored separately from the extension's code.

**Common install error:** "Manifest file is missing or unreadable" means
step 4 selected the wrong folder — go back and make sure you picked the
folder that directly contains `manifest.json`.

## Use it

1. Click the extension icon → fill in your profile (name, email, phone,
   links) and upload your resume file → **Save profile**. This is stored
   only in `chrome.storage.local` on your machine — nothing is sent
   anywhere except directly into a form field on a page you're already on.
2. Browse to any job application, anywhere. If the page looks like one,
   **⚡ Fill my info** appears bottom-right on its own — click it. If it
   doesn't appear (the heuristic is deliberately conservative), open the
   popup and click **"Fill this page"** instead, which works regardless.
3. **Review every field, especially custom questions**, then submit the
   application yourself as normal.

## Limitations, honestly

- **Auto-detection is a heuristic, not certainty.** It's tuned to avoid
  showing the button on random pages (a login form, a newsletter signup)
  by requiring several signals at once — occasionally that means it misses
  a real, unusually-structured application form. "Fill this page" from the
  popup always works as the fallback, regardless of what the button does.
- **LinkedIn and Indeed are not targeted**, even though the extension can
  technically reach them now — automating those violates their Terms of
  Service and is likely to get flagged. The auto-detect heuristic isn't
  tuned to recognize them.
- **Location autocomplete fields** (Google Places-style widgets some
  Greenhouse boards use) can't always be set programmatically the way a
  plain text box can — if location doesn't fill, type it manually.
- **Ashby forms, and other React-driven forms, sometimes render fields a
  beat after the page loads** — the button re-checks a couple of times in
  the first few seconds, but if the first click fills nothing, wait a
  second and click again.
- **Custom questions are never filled.** This is intentional, not a bug —
  those need your actual judgment.
- **Resume files** are capped at 8MB in the popup upload (plenty for a
  PDF/Word resume) and stored locally via `chrome.storage.local` with the
  `unlimitedStorage` permission, so you won't hit browser storage limits.

## Publishing it to the Chrome Web Store

Right now this only installs via "load unpacked" (Developer mode), which is
fine for personal use but means anyone else has to follow the same manual
steps. To make it a normal one-click install for other people:

1. Create a one-time Chrome Web Store developer account at
   https://chrome.google.com/webstore/devconsole — needs a Google account
   and a **$5 one-time registration fee**.
2. Zip just this extension folder (the one with `manifest.json` at its
   root — not the `store-assets` folder, which is reference material for
   the listing, not part of the extension itself) and upload it as a new
   item in the dashboard.
3. Fill in the store listing using `store-assets/STORE_LISTING.md` — it has
   ready-to-paste copy for the name, description, category, single-purpose
   statement, and permission justification (updated for the `<all_urls>`
   permission — that field needs a clear explanation or review can stall),
   plus the small promo tile image already generated at
   `store-assets/small_promo_tile_440x280.png`.
4. Add the privacy policy URL from `store-assets/STORE_LISTING.md` (a
   hosted page already written and published — see that file for the link,
   and for how to re-host it on your own domain instead if you prefer).
5. Take real screenshots of the extension in use (see the note in
   `STORE_LISTING.md`) and upload those too — required before submission.
6. Submit for review. Broad host permissions get closer scrutiny than a
   short domain list did, so review may take longer than the few-hours-to-
   a-few-days range this could otherwise expect — budget for that if the
   justification text gets questioned.

## Extending it

- `common/fill-utils.js` — shared low-level helpers (setting values in a
  framework-safe way, matching labels, attaching a resume file, showing the
  toast/button).
- `common/platform-fillers.js` — `jaFillGreenhouse`, `jaFillLever`,
  `jaFillAshby`: the optimized field maps for each platform.
- `common/generic-fill.js` — `jaFillGeneric`: the autocomplete/label-based
  fallback used for everything else.
- `content-scripts/detect-and-fill.js` — decides whether a page looks like
  an application (`jaLooksLikeApplicationForm`), picks which filler to run
  based on the frame's hostname, and wires up the button and the popup
  message listener.

To add a fourth optimized platform (SmartRecruiters, Workable, Recruitee,
etc. — all present in your `config.json`), write a new `jaFillX(profile)`
function in `platform-fillers.js` following the existing pattern, and add
its hostname to the `JA_KNOWN_HOSTS` map in `detect-and-fill.js`.
