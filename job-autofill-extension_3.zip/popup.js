const els = {
  firstName: document.getElementById("firstName"),
  lastName: document.getElementById("lastName"),
  email: document.getElementById("email"),
  phone: document.getElementById("phone"),
  location: document.getElementById("location"),
  currentCompany: document.getElementById("currentCompany"),
  linkedinUrl: document.getElementById("linkedinUrl"),
  portfolioUrl: document.getElementById("portfolioUrl"),
  githubUrl: document.getElementById("githubUrl"),
  coverLetterText: document.getElementById("coverLetterText"),
  resumeFile: document.getElementById("resumeFile"),
  resumeCurrent: document.getElementById("resumeCurrent"),
  resumeText: document.getElementById("resumeText"),
  saveStatus: document.getElementById("saveStatus"),
  fillStatus: document.getElementById("fillStatus"),
  fillNowBtn: document.getElementById("fillNowBtn"),
  form: document.getElementById("profileForm"),
  openaiApiKey: document.getElementById("openaiApiKey"),
  jobDescription: document.getElementById("jobDescription"),
  analyzeMatchBtn: document.getElementById("analyzeMatchBtn"),
  matchStatus: document.getElementById("matchStatus"),
  matchOutput: document.getElementById("matchOutput"),
};

let pendingResume = null; // set only if the user picks a new file this session

function loadProfile() {
  chrome.storage.local.get(["jaProfile"], (result) => {
    const p = result.jaProfile;
    if (!p) return;
    els.firstName.value = p.firstName || "";
    els.lastName.value = p.lastName || "";
    els.email.value = p.email || "";
    els.phone.value = p.phone || "";
    els.location.value = p.location || "";
    els.currentCompany.value = p.currentCompany || "";
    els.linkedinUrl.value = p.linkedinUrl || "";
    els.portfolioUrl.value = p.portfolioUrl || "";
    els.githubUrl.value = p.githubUrl || "";
    els.coverLetterText.value = p.coverLetterText || "";
    els.resumeText.value = p.resumeText || "";
    els.openaiApiKey.value = p.openaiApiKey || "";
    if (p.resume && p.resume.fileName) {
      els.resumeCurrent.textContent = `Saved resume: ${p.resume.fileName}`;
    }
  });
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      // reader.result is "data:<mime>;base64,<data>" — strip the prefix.
      const base64 = String(reader.result).split(",")[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

els.resumeFile.addEventListener("change", async () => {
  const file = els.resumeFile.files[0];
  if (!file) return;
  if (file.size > 8 * 1024 * 1024) {
    els.saveStatus.textContent = "That file is over 8MB — please pick a smaller resume file.";
    els.resumeFile.value = "";
    return;
  }
  const base64 = await fileToBase64(file);
  pendingResume = { fileName: file.name, mimeType: file.type, base64 };
  els.resumeCurrent.textContent = `Selected: ${file.name} (will be saved when you click "Save profile")`;
});

els.form.addEventListener("submit", (e) => {
  e.preventDefault();
  chrome.storage.local.get(["jaProfile"], (result) => {
    const existing = result.jaProfile || {};
    const firstName = els.firstName.value.trim();
    const lastName = els.lastName.value.trim();
    const profile = {
      firstName,
      lastName,
      fullName: [firstName, lastName].filter(Boolean).join(" "),
      email: els.email.value.trim(),
      phone: els.phone.value.trim(),
      location: els.location.value.trim(),
      currentCompany: els.currentCompany.value.trim(),
      linkedinUrl: els.linkedinUrl.value.trim(),
      portfolioUrl: els.portfolioUrl.value.trim(),
      githubUrl: els.githubUrl.value.trim(),
      coverLetterText: els.coverLetterText.value.trim(),
      resumeText: els.resumeText.value.trim(),
      openaiApiKey: els.openaiApiKey.value.trim(),
      resume: pendingResume || existing.resume || null,
    };
    chrome.storage.local.set({ jaProfile: profile }, () => {
      els.saveStatus.textContent = "Saved.";
      setTimeout(() => (els.saveStatus.textContent = ""), 2000);
    });
  });
});

function reportFillResult(response, chromeError) {
  if (chromeError || !response) {
    els.fillStatus.textContent = "Couldn't fill this page — see the note below.";
    return;
  }
  if (response.message === "no-profile") {
    els.fillStatus.textContent = "No saved profile yet — fill in your info below first.";
    return;
  }
  els.fillStatus.textContent =
    response.filled > 0
      ? `Filled ${response.filled} field(s). Review everything before you submit.`
      : "No matching fields found on this page.";
}

function injectAndFill(tabId, profile) {
  const files = [
    "common/fill-utils.js",
    "common/platform-fillers.js",
    "common/generic-fill.js",
    "content-scripts/detect-and-fill.js",
  ];
  chrome.scripting.executeScript({ target: { tabId }, files }, () => {
    if (chrome.runtime.lastError) {
      els.fillStatus.textContent =
        "Couldn't access this page — some pages (chrome://, the Web Store, PDFs) block extensions entirely.";
      return;
    }
    chrome.scripting.executeScript(
      { target: { tabId }, func: () => window.jaRunFillNow(), args: [] },
      (results) => {
        const response = results && results[0] && results[0].result;
        reportFillResult(response, chrome.runtime.lastError);
      }
    );
  });
}

els.fillNowBtn.addEventListener("click", () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.id) {
      els.fillStatus.textContent = "No active tab found.";
      return;
    }

    els.fillStatus.textContent = "Filling...";

    // The content script auto-attaches to every page (see manifest.json),
    // so this normally just works. The one case it doesn't: a tab that was
    // already open before the extension was installed/updated — Chrome
    // only injects content scripts into tabs loaded *after* that point.
    // For that case, fall back to injecting it on demand via activeTab,
    // which this popup click just granted for this one tab.
    chrome.tabs.sendMessage(tab.id, { type: "JA_FILL_NOW" }, (response) => {
      if (chrome.runtime.lastError) {
        chrome.storage.local.get(["jaProfile"], (result) => {
          if (!result.jaProfile) {
            els.fillStatus.textContent = "No saved profile yet — fill in your info below first.";
            return;
          }
          injectAndFill(tab.id, result.jaProfile);
        });
        return;
      }
      reportFillResult(response, null);
    });
  });
});

els.analyzeMatchBtn.addEventListener("click", async () => {
  const apiKey = els.openaiApiKey.value.trim();
  const resumeText = els.resumeText.value.trim();
  const jobDescription = els.jobDescription.value.trim();

  if (!apiKey || !apiKey.startsWith("sk-")) {
    els.matchStatus.textContent = "Add a valid OpenAI API key above first.";
    return;
  }
  if (!resumeText) {
    els.matchStatus.textContent = "Paste your resume text above first.";
    return;
  }
  if (!jobDescription) {
    els.matchStatus.textContent = "Paste the job description above first.";
    return;
  }

  els.matchStatus.textContent = "Analyzing (10-20 seconds)...";
  els.matchOutput.value = "";
  els.analyzeMatchBtn.disabled = true;

  const prompt = [
    "You are an ATS resume analyzer. Compare the resume to the job description below.",
    "List the most important keywords/skills from the job description that are missing or",
    "underrepresented in the resume, then give a short (2-3 sentence) honest assessment of fit.",
    "Do not invent experience the resume doesn't contain — only point out gaps.",
    "",
    "Job description:", "---", jobDescription, "---", "",
    "Resume:", "---", resumeText, "---",
    "",
    "Output format:",
    "Missing/weak keywords: <comma-separated list>",
    "Assessment: <2-3 sentences>",
  ].join("\n");

  try {
    const resp = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.3,
      }),
    });
    const data = await resp.json();
    if (!resp.ok) {
      throw new Error((data && data.error && data.error.message) || `Request failed (${resp.status})`);
    }
    const text = data.choices && data.choices[0] && data.choices[0].message
      ? data.choices[0].message.content
      : "";
    els.matchOutput.value = text || "(No response text returned.)";
    els.matchStatus.textContent = "Done — treat this as a starting point, not gospel.";
  } catch (err) {
    els.matchStatus.textContent = "Error: " + err.message;
  } finally {
    els.analyzeMatchBtn.disabled = false;
  }
});

loadProfile();
